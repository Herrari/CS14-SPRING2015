/*
Johnson Nguyen
861055939
April 14th, 2015

*/ 


#ifndef LAB2_H
#define LAB2_H


#include <forward_list>
#include <iostream>
using namespace std;

bool isPrime(int i ); // Declaration for function isPrime.

int primeCount( forward_list<int> lst ); // Declaration for Function primeCount.
























#endif